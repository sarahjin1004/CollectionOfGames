Blackjack
=============

This was something that was built just to see if I could.  Boredom + Coffee + JQuery = JQuery Blackjack game.

View a demo <a href='http://blackjack.cosmicapp.co'>here</a>.

Author
------
Tony Spiro
tspiro@tonyspiro.com

About
------
This is a blackjack program built using HTML5, JQuery and CSS.  It's just a starting point, please fork and make it better!

Copyright (C) 2013  Tony Spiro

    	This program is free software: you can redistribute it and/or modify
    	it under the terms of the GNU General Public License as published by
    	the Free Software Foundation, either version 3 of the License, or
    	any later version.

    	This program is distributed in the hope that it will be useful,
    	but WITHOUT ANY WARRANTY; without even the implied warranty of
    	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    	GNU General Public License for more details. http://www.gnu.org/licenses/
